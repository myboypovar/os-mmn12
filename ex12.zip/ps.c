#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

/* call to cps109, Leon Gold 315046409. */

int
main(int argc, char *argv[])
{
  cps109();
  exit(0);
}
